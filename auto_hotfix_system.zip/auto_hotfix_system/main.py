from agents import DiagnosisAgent, RepairAgent
from tools import DevTools


def start_auto_fix_workflow(alert_id):
    print("--- 🤖 开启多 Agent 协同修复流 ---")

    tools = DevTools()
    diagnoser = DiagnosisAgent()
    repairer = RepairAgent()

    # 1. 第一步：诊断
    analysis = diagnoser.analyze(alert_id, tools)
    print(f"📍 定位完成：{analysis['root_cause']} 在 {analysis['location']}")

    # 2. 第二步：循环修复与验证 (体现 Self-Correction 闭环)
    current_error = None
    is_fixed = False

    for attempt in range(3):  # 最多尝试 3 次推理修复
        # Agent 根据上次的错误反馈进行推理
        patch = repairer.propose_fix(analysis, last_error=current_error)

        # 在沙箱运行测试
        success, message = tools.run_tests(patch)

        if success:
            print("✅ 修复验证通过！")
            tools.submit_pr(patch)
            is_fixed = True
            break
        else:
            print(f"❌ 验证失败：{message}")
            current_error = message  # 将错误信息反馈给下一个循环的 Agent

    if not is_fixed:
        print("🔴 无法自动修复，已一键转人工处理，并同步诊断报告。")
    print("--- 🏁 流程结束 ---")


if __name__ == "__main__":
    start_auto_fix_workflow("ALARM_ID_5502")