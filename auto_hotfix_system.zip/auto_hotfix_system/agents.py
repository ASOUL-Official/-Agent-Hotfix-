import time


class DiagnosisAgent:
    """感知诊断 Agent：负责从海量指标中定位根因"""

    def analyze(self, alert_id, tools):
        print("🧠 [DiagnosisAgent] 正在进行长链推理：分析监控指标 -> 对比变更记录 -> 溯源堆栈...")
        time.sleep(1)
        # 模拟长链推理逻辑
        logs = tools.fetch_logs("TR-9901")
        return {
            "root_cause": "UserService 无法处理空用户对象",
            "location": "UserServiceImpl.java:45",
            "stack_trace": logs
        }


class RepairAgent:
    """修复 Agent：负责生成补丁并进行自我反思 (Self-Reflection)"""

    def __init__(self):
        self.reflection_count = 0

    def propose_fix(self, diagnosis, last_error=None):
        self.reflection_count += 1
        print(f"📝 [RepairAgent] 正在进行第 {self.reflection_count} 次自我反思与方案生成...")

        if last_error:
            print(f"🔄 [Reflection] 发现上次修复失败: {last_error}，正在修正推理路径...")
            return "public User getProfile(String id) { User user = repo.find(id); if (user == null) return null; return user; }"

        # 初始修复（故意漏掉 null 检查以演示闭环）
        return "public User getProfile(String id) { User user = repo.find(id); return user; }"